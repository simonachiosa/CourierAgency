<!DOCTYPE HTML>
<html>
<head>
<title>Inregistrare Comisie</title></head>
<body background="rmc.jpg" >
<form name="registration_form" action="registrationcomisie.php"method="post">
<center><b><h1>Inregistrare Comisie</h1></b></center>
<br><center>
<b><i>Nume:</i></b>
<input  id="ntext"  type="text" name="nume_comisie" value="" required /><br><br>
<b><i>Prenume:</i></b>
<input  id="ptext"  type="text" name="prenume_comisie" value="" required /><br><br>
<b><i>Email:</i></b>
<input  id="ptext"  type="text" name="email_comisie" value="" required/><br><br>
<b><i>Telefon:</i></b>
<input  id="ptext"  type="text" name="telefon_comisie" value="" maxlength="10" required/><br><br>
<b><i>Username:</i></b>
<input  id="utext"  type="text" name="username_comisie" value="" required /><br><br>
<b><i>Parola:</i></b>
<input  id="pp"  type="password" name="parola_comisie" value="" required/><br><br>
<button class"button">Inregistrare</button>
</center>
<body>
</body>
</html>