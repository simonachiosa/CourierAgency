<html>
<body>
<form action="insert.php" method="post">
<b>Username:</b>
<input type="text" name="Username" value=""  size="20" required /><br><br>
<b>Parola:</b>
<input type="text" name="Parola" value=""  size="20" required /><br><br>
    <input type="submit">
<form>
</body>
</html>